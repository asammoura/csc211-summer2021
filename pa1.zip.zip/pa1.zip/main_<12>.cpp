#include <iostream>

//input date numerically << output date literalily

int main() {
int a, b, c;
int average = a + b + c / 3;
    std::cout << "Enter 3 numbers between 1-9 ";
    std::cin >> a >> b >> c >> std::endl;


    std::cout << "The average of " + a + ", " + b + ", " + c + "is " + average << std::endl;
return 0;
}