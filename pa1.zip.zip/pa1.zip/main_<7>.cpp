#include <iostream>

//input a << output if/if not fits criteria

int main() {
int a;

std::cout << "Enter a number: ";
std::cin >> a >> std::endl;

if (a > 100) {
    if(a%8 == 0) {
        std::cout << a << " satisfies the criteria" << std::endl;
    }
    else if(a%8 !== 0) {
        std::cout << a << " does not satisfy the criteria" << std::endl;
    }
}
return 0;
}