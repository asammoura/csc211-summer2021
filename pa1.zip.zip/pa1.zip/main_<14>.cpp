#include <iostream>

//input 2 coordinates << output quadrant location

int main() {
double a, b;
    std::cout << "Enter 2 coordinates (either 1.0, -1.0) ";
    std::cin >> a >> b >> std::endl;

if (a == 1.0 && b == 1.0) {
    std::cout << "Quadrant 1" << std::endl;
}
if (a == 1.0 && b == -1.0) {
    std::cout << "Quadrant 2" << std::endl;
}
if (a == -1.0 && b == -1.0) {
    std::cout << "Quadrant 3" << std::endl;
}
if (a == -1.0 && b == 1.0) {
    std::cout << "Quadrant 4" << std::endl;
}
else if (a == 0.0 || b == 0.0) {
    std::cout << "No quadrant" << std::endl;
}
return 0;
}