#include <iostream>

//input a << output if last digit is 9

int main() {
int a;
int lastNumber = a % 10;

std::cout << "Enter a number: ";
std::cin >> a >> std::endl;

if (lastNumber == 9) {
    std::cout << a << " is good" << std::endl;
}
else {
    std::cout << a << " is no good" << std::endl;
}
return 0;
}