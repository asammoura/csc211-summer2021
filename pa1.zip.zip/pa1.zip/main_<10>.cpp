#include <iostream>

//input 1-9 << output word

int main() {
int a;

std::cout << "Enter a number 1-9: ";
std::cin >> a >> std::endl;

if (9 >= a && a >= 1) {

    switch (a) {
        case 1:
        std::cout << "One" << std::endl;
        case 2:
        std::cout << "Two" << std::endl;
        case 3:
        std::cout << "Three" << std::endl;
        case 4:
        std::cout << "Four" << std::endl;
        case 5:
        std::cout << "Five" << std::endl;
        case 6:
        std::cout << "Six" << std::endl;    
        case 7:
        std::cout << "Seven" << std::endl;
        case 8:
        std::cout << "Eight" << std::endl;    
        case 9:
        std::cout << "Nine" << std::endl;
    }
}
else {
    std::cout << "Not a valid number" << std::endl;
}
return 0;
}