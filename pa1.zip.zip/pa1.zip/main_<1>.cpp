#include <iostream>

//input a,b << output a+b

int main () {
int a, b;
int c = a + b;

std::cin >> a >> b >> std::endl;

std::cout << a << " + " << b << " = " << c << std::endl;
return 0;
}
