#include <iostream>

//input date numerically << output date literalily

int main() {
int a, b, c;

std::cout << "Enter your birthday in the format: <month> <day> <year>: ";
std::cin >> a >> b >> c >> std::endl;

if (12 >= a && a >= 1) {

    switch (a) {
        case 1:
        std::cout << "January ";
        case 2:
        std::cout << "February ";
        case 3:
        std::cout << "March ";
        case 4:
        std::cout << "April ";
        case 5:
        std::cout << "May ";
        case 6:
        std::cout << "June ";    
        case 7:
        std::cout << "July ";
        case 8:
        std::cout << "August ";    
        case 9:
        std::cout << "September ";
        case 10:
        std::cout << "October ";
        case 11:
        std::cout << "November ";
        case 12:
        std::cout << "December ";
    }
}
else {
    std::cout << "Imaginary month ";
}
    std::cout << b + ", ";
    std::cout << c << std::endl;
return 0;
}