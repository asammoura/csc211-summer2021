#include <iostream>

//input temperature in F << output temp in C

int main() {
double a;
char b;
    std::cout << "Enter the temperature and F or C (Farenheit or Celsius respectively): ";
    std::cin >> a >> b >> std::endl;

if (b == "F") {
    std::cout << a << " degrees F is equal to " << (a - 32.0) * 5.0/9.0 << " degrees C" << std::endl;
}
if (b == "C") {
    std::cout << a << " degrees C is ewqual to " (a * 9.0) / 5.0 + 32 << " degrees F" << std::endl;
}
return 0;
}