#include <iostream>

//input 3 integers << output smallest integer

int main() {
int a, b, c;
    std::cout << "Enter 3 numbers: ";
    std::cin >> a >> b >> c >> std::endl;

if (a < b && a < c) {
    std::cout << "The smallest number is " << a << std::endl;
}
else if (b < a && b < c) {
    std::cout << "The smallest number is " << b << std::endl;
}
else if (c < a && c < b) {
    std::cout << "The smallest number is " << c << std::endl;
}
return 0;
}