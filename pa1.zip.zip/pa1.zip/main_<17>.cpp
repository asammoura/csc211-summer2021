#include <iostream>

//input letter grade << output outcome

int main() {
char a;

    std::cout << "Enter your letter grade: ";
    std::cin >> a >> std::endl;

if (a == "A" || a == "a") {
    std::cout << "Excellent" << std::endl;
}
if (a == "B" || a == "b") {
    std::cout << "Good" << std::endl;
}
if (a == "C" || a == "c") {
    std::cout << "Average" << std::endl;
}
if (a == "D" || a == "d") {
    std::cout << "Poor" << std::endl;
}
if (a == "F" || a == "f") {
    std::cout << "Failing" << std::endl;
}
return 0;
}