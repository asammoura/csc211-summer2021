#include <iostream>

//input angles << output type of triangle

int main() {
    int a, b, c

    std::cout << "Enter the 3 angles of the triangle: ";
    std::cin >> a >> b >> c >> std::endl;

    if (a + b + c !== 180) {
    std::cout << "This triangle is impossible" << std::endl;
    }
    if (a < 90 && b < 90 && c < 90) {
        std::cout << "This is an Acute triangle" << std::endl;
    }
    if (a == 90 || b == 90 || c == 90) {
        std::cout << "This is a Right triangle" << std::endl;
    }
    if (a > 90 || b > 90 || c > 90) {
        std::cout << "This is an Obtuse triangle" << std::endl;
    }
    

return 0;
}