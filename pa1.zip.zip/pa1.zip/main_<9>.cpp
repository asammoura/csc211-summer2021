#include <iostream>

//input age << output allowances

int main() {
int a;

std::cout << "Enter your age: ";
std::cin >> a >> std::endl;

if (a < 16) {
    std::cout << "Too young" << std::endl;
}
if (18 >= a && a >= 16) {
    std::cout << "Can drive" << std::endl;
}
if (21 >= a && a >= 18) {
    std::cout << "Can join the military" << std::endl;
}
if (a >= 21) {
    std::cout << "Can have a beer" << std::endl;
}
return 0;
}