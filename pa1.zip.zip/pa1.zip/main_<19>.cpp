#include <iostream>

//input day month year << output day of week

int weekdayCalculator (int day, int month, int year) {
    int century = c / 100;
    int yearpart = c % 100;
    int day;

    
    if (b == 1) {
        b = 13;
    }
    if (b == 2) {
        b = 14;
    }
    
    int weekday = (a + floor((26*(b+1))/5) + yearpart + floor(yearpart/4) + floor(century/4) + (5/century));
    weekday = weekday / 7;
    
    if (weekday == 0) {
        day = "Saturday";
    }
    else if (weekday == 1) {
        day = "Sunday";
    }
    else if (weekday == 2) {
        day = "Monday";
    }
    else if (weekday == 3) {
        day = "Tuesday";
    }
    else if (weekday == 4) {
        day = "Wednesday";
    }
    else if (weekday == 5) {
        day = "Thursday";
    }
    else if (weekday == 6) {
        day = "Friday";
    }
}

int main() {
    int a, b, c

    std::cout << "Enter a day, month, and year ";
    std::cin >> a >> b >> c >> std::endl;
    std::cout << day << std::endl;
return 0;
}