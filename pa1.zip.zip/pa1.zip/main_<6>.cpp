#include <iostream>

//input a << output positive or negative

int main() {
int a;

std::cout << "Enter a number: ";
std::cin >> a >> std::endl;

if (a < 0) {
    std::cout << a << "is negative" << std::endl;
}
else {
    std::cout << a << "is positive" << std::endl;
}
return 0;
}