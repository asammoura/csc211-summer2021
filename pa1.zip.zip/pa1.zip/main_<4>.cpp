#include <iostream>

//input a,b,c

int main() {
int a,b;
char c;
int d = a + c + b;


std::cout << "Enter 2 Numbers and a Basic Operator (+, -, /, *)";
std::cin >> a >> b >> c >> std::endl;


std::cout << a << c << b << " = " << d << std::endl;
return 0;
}