#include <iostream>

//input a,b << output even/odd

int main() {
int a;

std::cout << "Enter a number: ";
std::cin >> a << std::endl;

if (a%2 == 0) {
    std::cout << a << " is even" << std::endl;
}
else {
    std::cout << a << " is odd" << std::endl;
}
return 0;
}