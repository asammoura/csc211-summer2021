#include <iostream>

//input temperature << output advice on weather

int main() {
double a;
    std::cout << "Enter the temperature in Farenheit: ";
    std::cin >> a >> std::endl;

if (a <= 32.0) {
    std::cout << "It is cold out" << std::endl;
}
if (a <= 65.0 && a >= 32.0) {
    std::cout << "Wear a jacket" << std::endl;
}
if (a > 65.0) {
    std::cout << "It is nice out" << std::endl;
}
return 0;
}